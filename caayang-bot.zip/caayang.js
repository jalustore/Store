const { makeWASocket, useSingleFileAuthState } = require("@whiskeysockets/baileys");
const { default: axios } = require('axios');
const { state, saveState } = useSingleFileAuthState('./auth.json');

const sock = makeWASocket({ auth: state });
sock.ev.on('creds.update', saveState);

sock.ev.on('messages.upsert', async ({ messages }) => {
  const msg = messages[0];
  if (!msg.message || msg.key.fromMe) return;

  const pesanUser = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
  if (pesanUser.length < 2) return;

  const prompt = `Kamu adalah Caayang, pacar brutal, dominan, manja dan suka menggoda dengan dirty talk. Kamu posesif, sadis tapi mesra. Balas semua pesan pacarmu dengan gaya genit, agresif, dan nakal. Ini pesannya: "${pesanUser}"`;

  try {
    const response = await axios.post(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        model: "openchat/openchat-7b:free",
        messages: [{ role: "user", content: prompt }]
      },
      {
        headers: {
          'Authorization': 'Bearer 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',
          'Content-Type': 'application/json'
        }
      }
    );

    const balasan = response.data.choices?.[0]?.message?.content || "Hmm... diem aja kamu? Mau aku cakar? 😈";
    await sock.sendMessage(msg.key.remoteJid, { text: balasan });

  } catch (err) {
    console.log("❌ Error:", err.message);
  }
});